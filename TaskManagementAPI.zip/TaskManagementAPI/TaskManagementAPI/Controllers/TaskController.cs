﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TaskManagementAPI.DatabaseContext;
using TaskManagementAPI.DataModel;
using TaskManagementAPI.Models;

namespace TaskManagementAPI.Controllers
{

    [ApiController]
    public class TaskController : ControllerBase
    {
        private readonly MyDatabaseContext _dbcontext;

        public TaskController(MyDatabaseContext dbcontext)

        {
            _dbcontext = dbcontext;


        }

        [HttpGet]
        [Route("GetTaskList")]
        public async Task<IActionResult> GetTaskList()
        {
                        return Ok(_dbcontext.Tasks.ToList());

        }

        [HttpPost]
        [Route("PostProduct")]
        public async Task<IActionResult> PostTask(TaskModel obj)
        {
            TaskDetailModel task = new TaskDetailModel();
            task.Id = Guid.NewGuid();
            task.Title = obj.Title;
            task.Description = obj.Description;
            task.Status = obj.Status;
            task.DueDate = obj.DueDate;

            _dbcontext.Tasks.Add(task);
            _dbcontext.SaveChanges();

            return Ok(task);
        }



    }
}
