﻿using Microsoft.EntityFrameworkCore;
using TaskManagementAPI.DataModel;

namespace TaskManagementAPI.DatabaseContext
{
    public class MyDatabaseContext:DbContext    
    {

        protected override void OnConfiguring
        (DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseInMemoryDatabase(databaseName: "TaskDb");
        }



        public DbSet<TaskDetailModel> Tasks { get; set; }

    }
}
