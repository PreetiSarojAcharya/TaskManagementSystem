import { TaskDataService } from 'src/app/services/task-data.service';
import { Component, OnInit } from '@angular/core';
import {FormGroup,FormBuilder, FormControl} from '@angular/forms';
import { Task } from 'src/app/model/task';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

taskDetail !: FormGroup;
taskObj : Task=new Task();
taskList : Task[] = [];

  constructor(private formBuilder:FormBuilder, private taskDataService: TaskDataService) { }

  ngOnInit(): void {
      this.getAllTask();
this.taskDetail= this.formBuilder.group({
title:[''],
description:[],
status:[],
duedate:[]
});


  }

  addTask(){

    console.log(this.taskDetail);
    this.taskObj.id=this.taskDetail.value.id;
       this.taskObj.title=this.taskDetail.value.title;
   this.taskObj.description=this.taskDetail.value.description;
      this.taskObj.status=this.taskDetail.value.status;
         this.taskObj.dueDate=this.taskDetail.value.dueDate;
this.taskDataService.addTask(this.taskObj).subscribe(res=>{

  console.log(res);
  this.getAllTask();
},err=>{console.log(err);});
  }

  getAllTask(){
this.taskDataService.getAllTask().subscribe(res=>{
this.taskList=res;

},err=>{
  console.log("error while fetching");
})


  }

}
