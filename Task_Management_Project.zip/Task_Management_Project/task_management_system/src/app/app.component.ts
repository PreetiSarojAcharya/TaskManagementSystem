import { Component } from '@angular/core';
// import {TaskDataService} from './services/task-data.service'
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'task_management_system';
  //users:any;
  constructor(){}
// constructor(private taskData:TaskDataService)

// {

// taskData.users().subscribe((data)=>{
  
//   console.warn("data",data);
//   this.users=data});
// //console.warn(this.users);

// }
}
