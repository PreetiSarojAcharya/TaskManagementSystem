export class Task {
    id:number=0;
    title:string='';
    description:string='';
      status:string='';
        dueDate:string='';
}
