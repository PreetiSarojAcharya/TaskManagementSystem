import { Injectable } from '@angular/core';
import {HttpClient,HttpClientModule} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Task } from '../model/task';


@Injectable({
  providedIn: 'root'
})
export class TaskDataService {
posturl="http://localhost:5141/PostProduct";
geturl="http://localhost:5141/GetTaskList"
  constructor(private http:HttpClient) { }

addTask(task : Task):Observable<Task>
{
return this.http.post<Task>(this.posturl,task);
  
}

getAllTask(): Observable<Task[]>{

 return this.http.get<Task[]>(this.geturl);
}

}
